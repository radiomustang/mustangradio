import { useRef, useState } from "react";
import { useEffect } from "react";

export default function RadioMustangApp() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [lang, setLang] = useState("nl");
  const audioRef = useRef(null);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(reg => console.log('Service Worker registered:', reg))
        .catch(err => console.error('Service Worker registration failed:', err));
    }
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio("https://s3.free-shoutcast.com/stream/18052");
      audioRef.current.crossOrigin = "anonymous";
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play()
        .then(() => setIsPlaying(true))
        .catch((err) => {
          console.error("Playback error:", err);
          alert(lang === 'nl' ? "Kan de stream niet afspelen. Probeer het opnieuw of controleer de stream-URL." : "Cannot play the stream. Please try again or check the stream URL.");
        });
    }
  };

  const toggleLanguage = () => {
    setLang(lang === 'nl' ? 'en' : 'nl');
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4 bg-cover bg-center" style={{ backgroundImage: 'url(/mustang.jpg)' }}>
      <div className="absolute top-4 right-4">
        <button
          onClick={toggleLanguage}
          className="bg-white/20 text-white px-4 py-2 rounded-lg text-sm hover:bg-white/30"
        >
          {lang === 'nl' ? 'English' : 'Nederlands'}
        </button>
      </div>

      <div className="bg-black/70 p-6 rounded-2xl shadow-lg text-center">
        <h1 className="text-4xl font-bold mb-6">Radio Mustang</h1>
        <button
          onClick={togglePlay}
          className="bg-white text-black px-6 py-3 rounded-full text-xl shadow hover:bg-gray-300 transition"
        >
          {isPlaying ? (lang === 'nl' ? 'Pauzeer' : 'Pause') : (lang === 'nl' ? 'Luister Live' : 'Listen Live')}
        </button>
      </div>

      <div className="mt-12 bg-black/70 p-6 rounded-xl w-full max-w-md">
        <h2 className="text-2xl font-semibold mb-4">{lang === 'nl' ? 'Contact' : 'Contact'}</h2>
        <p>{lang === 'nl' ? 'Email' : 'Email'}: <a href="mailto:radio.mustang@hotmail.com" className="underline">radio.mustang@hotmail.com</a></p>
      </div>
    </div>
  );
}